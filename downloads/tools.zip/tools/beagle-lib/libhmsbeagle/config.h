/* libhmsbeagle/config.h.  Generated from config.h.in by configure.  */
/* libhmsbeagle/config.h.in.  Generated from configure.ac by autoheader.  */

/* Support AVX (Advanced Vector Extensions) instructions */
/* #undef HAVE_AVX */

/* Define to 1 if you have the <cpuid.h> header file. */
#define HAVE_CPUID_H 1

/* Define to 1 if you have the <dlfcn.h> header file. */
#define HAVE_DLFCN_H 1

/* Define to 1 if you have the <inttypes.h> header file. */
#define HAVE_INTTYPES_H 1

/* "Defined if the libtool dev libs are present" */
#define HAVE_LIBLTDL "1"

/* Define to 1 if you have the <memory.h> header file. */
#define HAVE_MEMORY_H 1

/* Support MMX instructions */
#define HAVE_MMX /**/

/* Support SSE (Streaming SIMD Extensions) instructions */
#define HAVE_SSE /**/

/* Support SSE2 (Streaming SIMD Extensions 2) instructions */
#define HAVE_SSE2 /**/

/* Support SSE3 (Streaming SIMD Extensions 3) instructions */
#define HAVE_SSE3 /**/

/* Support SSE4.1 (Streaming SIMD Extensions 4.1) instructions */
/* #undef HAVE_SSE41 */

/* Support SSE4.2 (Streaming SIMD Extensions 4.2) instructions */
/* #undef HAVE_SSE42 */

/* Support SSSE3 (Supplemental Streaming SIMD Extensions 3) instructions */
#define HAVE_SSSE3 /**/

/* Define to 1 if you have the <stdint.h> header file. */
#define HAVE_STDINT_H 1

/* Define to 1 if you have the <stdlib.h> header file. */
#define HAVE_STDLIB_H 1

/* Define to 1 if you have the <strings.h> header file. */
#define HAVE_STRINGS_H 1

/* Define to 1 if you have the <string.h> header file. */
#define HAVE_STRING_H 1

/* Define to 1 if you have the <sys/stat.h> header file. */
#define HAVE_SYS_STAT_H 1

/* Define to 1 if you have the <sys/types.h> header file. */
#define HAVE_SYS_TYPES_H 1

/* Define to 1 if you have the <unistd.h> header file. */
#define HAVE_UNISTD_H 1

/* Define to the sub-directory in which libtool stores uninstalled libraries.
   */
#define LT_OBJDIR ".libs/"

/* Define to the address where bug reports for this package should be sent. */
#define PACKAGE_BUGREPORT "beagle-dev@googlegroups.com"

/* Define to the full name of this package. */
#define PACKAGE_NAME "libhmsbeagle"

/* Define to the full name and version of this package. */
#define PACKAGE_STRING "libhmsbeagle 2.1.2"

/* Define to the one symbol short name of this package. */
#define PACKAGE_TARNAME "libhmsbeagle"

/* Define to the home page for this package. */
#define PACKAGE_URL ""

/* Define to the version of this package. */
#define PACKAGE_VERSION "2.1.2"

/* "Define version number for plugins" */
#define PLUGIN_VERSION "21"

/* Define to 1 if you have the ANSI C header files. */
#define STDC_HEADERS 1
